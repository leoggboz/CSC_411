load a1spam;

disp('Feature names (vocabulary)');
pause;
disp(feature_names);
pause;

disp('Non-spam example');
pause;
disp(feature_names(logical(data_train(1,:))));
pause;

disp('Non-spam example encoded');
pause;
disp(data_train(1,:));
pause;

disp('Spam example');
pause;
disp(feature_names(logical(data_train(800,:))));
pause;

disp('Spam example encoded');
pause;
disp(data_train(800,:));
pause;

disp('Running Naive Bayes... ');
[pcond, prior] = nb(data_train, labels_train);
disp('Finished...');
pause;

disp('Prior probability');
pause;
disp(prior);
pause;

disp('Top words for spam:');
pause;
topwords(pcond(2,:), 10, feature_names, 1);
pause;

disp('Top words for nonspam:');
pause;
topwords(pcond(1,:), 10, feature_names, 1);
pause;

class1probs = repmat(pcond(1,:),4000,1);
class1data = data_valid .* class1probs + ...
             (1 - data_valid) .* (1 - class1probs);

class2probs = repmat(pcond(2,:),4000,1);
class2data = data_valid .* class2probs + ...
             (1 - data_valid) .* (1 - class2probs);

labels = prior(1) * prod(class1data,2) < prior(2) * prod(class2data,2);
disp('Prediction');
pause;
disp(labels');
pause;

disp('Accuracy');
pause;
disp(sum(labels == labels_valid) / 4000);


